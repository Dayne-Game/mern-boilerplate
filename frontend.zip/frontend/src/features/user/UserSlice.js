import { createSlice, createAsyncThunk } from "@reduxjs/toolkit"
import UserService from './UserService'
import jwt_decode from "jwt-decode";

let token = localStorage.getItem('token');

const initialState = {
    user: token ? jwt_decode(token) : null,
    isError: false,
    isSuccess: false,
    isLoading: false,
    message: '',
}

// Login user
export const login = createAsyncThunk('user/login', async (user, thunkAPI) => {
    try {
      return await UserService.login(user)
    } catch (error) {
      const message = (error.response && error.response.data && error.response.data.message) || error.message || error.toString()
      return thunkAPI.rejectWithValue(message)
    }
})

// Logout  
export const logout = createAsyncThunk('user/logout', async () => {
    await UserService.logout()
})

export const UserSlice = createSlice({
    name: 'user',
    initialState,
    reducers: {
        reset: (state) => {
            state.isLoading = false
            state.isSuccess = false
            state.isError = false
            state.message = ''
        },
    },
    extraReducers: (builder) => {
    builder
        .addCase(login.pending, (state) => {
        state.isLoading = true
        })
        .addCase(login.fulfilled, (state, action) => {
        state.isLoading = false
        state.isSuccess = true
        state.user = action.payload
        })
        .addCase(login.rejected, (state, action) => {
        state.isLoading = false
        state.isError = true
        state.message = action.payload
        state.user = null
        })
        .addCase(logout.fulfilled, (state) => {
        state.user = null
        })
    },
})

export const { reset } = UserSlice.actions
export default UserSlice.reducer;