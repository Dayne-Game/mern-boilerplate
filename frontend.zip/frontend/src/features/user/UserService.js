import axios from 'axios';
import { DecodeToken } from '../../helper/DecodeToken';

const API_URL = '/api/users/';

// Login User
const login = async (user_data) => {

    const response = await axios.post(API_URL + 'login', user_data)

    if(response.data) {
        // Add Token
        localStorage.setItem('token', JSON.stringify(response.data));
    }   
    
    return DecodeToken(response.data);
};

// Logout User
const logout = () => {
    localStorage.clear();
};

const UserService = {
    login, logout
}       

export default UserService;