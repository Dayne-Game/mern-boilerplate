import { useEffect } from 'react'
import { useNavigate } from 'react-router-dom'
import { useSelector } from 'react-redux'

function TimeLog() {
    const navigate = useNavigate()
  
    const { user } = useSelector((state) => state.user)

  
    useEffect(() => {
      if (!user) {
        navigate('/login')
      }

    }, [user, navigate ])

    return (
        <>
          <h1>Time Logs</h1>
        </>
    )
}

export default TimeLog;